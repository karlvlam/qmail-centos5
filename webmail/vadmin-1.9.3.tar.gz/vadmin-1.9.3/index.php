<?php
/**
 * index.php
 * ---------
 * Placeholder for curious individuals.
 *
 * $Id: index.php,v 1.2 2003/06/09 04:12:03 graf25 Exp $
 */
?>
<html><body></body></html>
