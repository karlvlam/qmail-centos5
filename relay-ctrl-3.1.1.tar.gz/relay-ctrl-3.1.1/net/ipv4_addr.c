#include "ipv4.h"

ipv4addr IPV4ADDR_ANY = { 0,0,0,0 };
ipv4addr IPV4ADDR_BROADCAST = { 255,255,255,255 };
