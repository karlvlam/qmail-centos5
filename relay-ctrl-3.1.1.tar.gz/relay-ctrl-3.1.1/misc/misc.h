#ifndef MISC__H__
#define MISC__H__

unsigned long strtou(const char* str, const char** end);
const char* utoa(unsigned long);
char* utoa2(unsigned long, char*);

#endif
