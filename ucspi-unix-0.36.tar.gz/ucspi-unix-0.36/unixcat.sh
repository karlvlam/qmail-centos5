exec unixclient "$1" sh -c 'exec cat <&6'
