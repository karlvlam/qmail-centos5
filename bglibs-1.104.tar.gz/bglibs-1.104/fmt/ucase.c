#include "number.h"

/** Array of digits for upper-case conversions */
const char fmt_ucase_digits[36] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
