#include "number.h"

/** Array of digits for lower-case conversions */
const char fmt_lcase_digits[36] = "0123456789abcdefghijklmnopqrstuvwxyz";
