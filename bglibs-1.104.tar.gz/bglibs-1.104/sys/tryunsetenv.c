#include <stdlib.h>

void main(void) {
  unsetenv("PATH");
}
