#include "systime.h"

struct timespec ts;
