int symbol __attribute__((__const__));
