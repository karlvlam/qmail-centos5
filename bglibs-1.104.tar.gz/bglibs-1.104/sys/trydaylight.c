extern int daylight;
int main(void) {
	return daylight;
}
