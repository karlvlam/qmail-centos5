int symbol __attribute__((__deprecated__));
