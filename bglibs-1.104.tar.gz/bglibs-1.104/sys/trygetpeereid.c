#include <sys/types.h>
#include <unistd.h>

void main()
{
  getpeereid();
}
