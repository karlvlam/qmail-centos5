#include "zlib.h"

int main(void) {
  z_stream test;
  return 0;
}
