#include <stdlib.h>

int main()
{
  setenv("FOO", "bar", 1);
  return 0;
}
