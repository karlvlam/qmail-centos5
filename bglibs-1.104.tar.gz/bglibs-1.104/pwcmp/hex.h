#ifndef PW_CMP__HEX__H__
#define PW_CMP__HEX__H__

extern void hex_encode(const unsigned char* bin, unsigned long len, char* hex);
extern const char hex_digits[16];

#endif
