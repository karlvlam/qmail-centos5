#ifndef CLI__INTERNAL__H__
#define CLI__INTERNAL__H__

extern cli_option cli_help_option;
extern cli_option** cli_full_options;
extern unsigned cli_option_count;

#endif
