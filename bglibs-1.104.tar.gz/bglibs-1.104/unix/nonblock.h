#ifndef UNIX__NONBLOCK__H__
#define UNIX__NONBLOCK__H__

int nonblock_on(int fd);
int nonblock_off(int fd);

#endif
