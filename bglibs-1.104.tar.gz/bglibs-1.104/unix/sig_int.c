#include <signal.h>
#include "sig.h"

SIG_FUNCTION_MAKE(int, SIGINT);
