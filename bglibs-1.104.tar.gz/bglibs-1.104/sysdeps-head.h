#ifndef SYS_DEPS__H__
#define SYS_DEPS__H__

#include <sys/types.h>
typedef unsigned char uint8;
typedef unsigned short uint16;
